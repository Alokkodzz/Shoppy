using OrderService.Entities;

namespace OrderService.DTOs
{
    public class OrderStatusDto
    {
        public string Status { get; set; }
    }
}